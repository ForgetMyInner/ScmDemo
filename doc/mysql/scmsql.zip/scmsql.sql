-- --------------------------------------------------------
-- 主机:                           127.0.0.1
-- 服务器版本:                        8.0.27 - MySQL Community Server - GPL
-- 服务器操作系统:                      Win64
-- HeidiSQL 版本:                  11.3.0.6321
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 导出 scm_db 的数据库结构
CREATE DATABASE IF NOT EXISTS `scm_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `scm_db`;

-- 导出  表 scm_db.admin 结构
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '用户名',
  `password` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '密码',
  `salt` varchar(64) NOT NULL COMMENT '盐',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '昵称',
  `stop` bit(1) DEFAULT b'0' COMMENT '账号状态（0正常 1停用）',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `phone` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '手机号',
  `sex` char(2) DEFAULT NULL COMMENT '用户性别',
  `avatar` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '头像',
  `super_user` bit(1) DEFAULT b'0' COMMENT '用户类型（1管理员，0普通用户）',
  `login_ip` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '最后登录IP',
  `login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `login_count` int DEFAULT '0' COMMENT '登录次数',
  `create_by` int DEFAULT NULL COMMENT '创建人的用户id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` int DEFAULT NULL COMMENT '更新人',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `enable` bit(1) DEFAULT (1) COMMENT '删除标志（1代表未删除，0代表已删除）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员用户表';

-- 正在导出表  scm_db.admin 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- 导出  表 scm_db.arrival_plan 结构
CREATE TABLE IF NOT EXISTS `arrival_plan` (
  `id` int NOT NULL,
  `purchase_order_arrival` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '到货批次(数据库字典—）',
  `plan_arrival_date` datetime DEFAULT NULL COMMENT '计划到货日期',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `purchase_order_id` int DEFAULT NULL COMMENT '采购订单id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='采购申请到货计划表';

-- 正在导出表  scm_db.arrival_plan 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `arrival_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `arrival_plan` ENABLE KEYS */;

-- 导出  表 scm_db.attachment 结构
CREATE TABLE IF NOT EXISTS `attachment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '证书名称',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '证书类型（数据库字典）',
  `supplier_id` int DEFAULT NULL COMMENT '供应商_id',
  `enable` bit(1) DEFAULT b'1' COMMENT '（0删除 ）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='附件表';

-- 正在导出表  scm_db.attachment 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;

-- 导出  表 scm_db.company_department 结构
CREATE TABLE IF NOT EXISTS `company_department` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '部门名称',
  `sort` int DEFAULT NULL COMMENT '排序',
  `leader` varchar(50) DEFAULT NULL COMMENT '领导人',
  `phone` varchar(11) DEFAULT NULL COMMENT '手机号',
  `email` varchar(20) DEFAULT NULL COMMENT '邮箱',
  `enter_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '录入人',
  `enter_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '更新人',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `stop` bit(1) DEFAULT b'1' COMMENT '是否禁用   0表示禁用',
  `enable` bit(1) DEFAULT b'1' COMMENT '是否删除  0表示删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='公司部门表';

-- 正在导出表  scm_db.company_department 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `company_department` DISABLE KEYS */;
/*!40000 ALTER TABLE `company_department` ENABLE KEYS */;

-- 导出  表 scm_db.contactinfo 结构
CREATE TABLE IF NOT EXISTS `contactinfo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` int NOT NULL COMMENT '联系人名称',
  `job` int NOT NULL COMMENT '职位',
  `phone` varchar(11) DEFAULT NULL COMMENT '联系人电话',
  `email` varchar(50) DEFAULT NULL COMMENT '联系人邮箱',
  `is_important` bit(1) DEFAULT b'0' COMMENT '1表示重要联系人  0表示备用联系人',
  `supplier_id` int DEFAULT NULL COMMENT '供应商id',
  `enable` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商的联系人信息表';

-- 正在导出表  scm_db.contactinfo 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `contactinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `contactinfo` ENABLE KEYS */;

-- 导出  表 scm_db.deliver_person 结构
CREATE TABLE IF NOT EXISTS `deliver_person` (
  `id` int NOT NULL,
  `supplier_id` int DEFAULT NULL COMMENT '供应商id',
  `shipper_name` varchar(255) DEFAULT NULL COMMENT '发货人姓名',
  `shipper_phone` varchar(255) DEFAULT NULL COMMENT '发货人联系方式',
  `driver_name` varchar(255) DEFAULT NULL COMMENT '司机姓名',
  `driver_phone` varchar(255) DEFAULT NULL COMMENT '司机联系方式',
  `car_num` varchar(255) DEFAULT NULL COMMENT '车牌号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='送货联系人';

-- 正在导出表  scm_db.deliver_person 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `deliver_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliver_person` ENABLE KEYS */;

-- 导出  表 scm_db.deliver_product_details 结构
CREATE TABLE IF NOT EXISTS `deliver_product_details` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchase_apply_id` int DEFAULT NULL COMMENT '采购申请id获得采购产品明细下的产品信息',
  `deliver_goods_num` int DEFAULT NULL COMMENT '送货适量',
  `is_delivered` bit(1) DEFAULT NULL COMMENT '是否送达',
  `delivered_imgs` int DEFAULT NULL COMMENT '附件图片id',
  `in_warehouse_sure` bit(1) DEFAULT NULL COMMENT '入库验证',
  `real_product_num` int DEFAULT NULL COMMENT '本次到货数量',
  `not_eligible` int DEFAULT NULL COMMENT '不合格数量',
  `in_warehouse_num` int DEFAULT NULL COMMENT '本次入库数量',
  `have_eligible` bit(1) DEFAULT NULL COMMENT '是否存在不合格产品',
  `quality_time` datetime DEFAULT NULL COMMENT '质检时间',
  `quality_person` int DEFAULT NULL COMMENT '当前质检员',
  `quality_person_dep` int DEFAULT NULL COMMENT '部门',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='送货产品明细表';

-- 正在导出表  scm_db.deliver_product_details 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `deliver_product_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliver_product_details` ENABLE KEYS */;

-- 导出  表 scm_db.deliver_product_review 结构
CREATE TABLE IF NOT EXISTS `deliver_product_review` (
  `deliver_product_details_id` int DEFAULT NULL COMMENT '送货明细表id',
  `qualified_ensure` bit(1) DEFAULT NULL COMMENT '入库确认',
  `imgs_id` int DEFAULT NULL COMMENT '入库图片',
  `inwarehouse_time` int DEFAULT NULL COMMENT '入库时间',
  `inwarehouse_person` int DEFAULT NULL COMMENT '入库人',
  `person_dep` int DEFAULT NULL COMMENT '所属部门'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='采购入库审核表';

-- 正在导出表  scm_db.deliver_product_review 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `deliver_product_review` DISABLE KEYS */;
/*!40000 ALTER TABLE `deliver_product_review` ENABLE KEYS */;

-- 导出  表 scm_db.employee 结构
CREATE TABLE IF NOT EXISTS `employee` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT '员工名称',
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT '员工手机号',
  `sex` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '性别',
  `job` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT '职位',
  `company_department_id` int DEFAULT NULL COMMENT '所属部门',
  `enable` bit(1) DEFAULT b'1' COMMENT '逻辑删除 0表示删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='员工表';

-- 正在导出表  scm_db.employee 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;

-- 导出  表 scm_db.finance 结构
CREATE TABLE IF NOT EXISTS `finance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Invoice_header` varchar(50) DEFAULT NULL COMMENT '发票抬头',
  `tax_num` int DEFAULT NULL COMMENT '发票税号',
  `tax_type` int DEFAULT NULL COMMENT '税种',
  `tax_rate` int DEFAULT NULL COMMENT '增值税税率',
  `bank` varchar(50) DEFAULT NULL COMMENT '开户银行',
  `enable` bit(1) DEFAULT b'1' COMMENT '0 删除   ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='财务表';

-- 正在导出表  scm_db.finance 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `finance` DISABLE KEYS */;
/*!40000 ALTER TABLE `finance` ENABLE KEYS */;

-- 导出  表 scm_db.imgs 结构
CREATE TABLE IF NOT EXISTS `imgs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL COMMENT '谁用到的id',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '类型',
  `remark` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '备注',
  `sort` int NOT NULL,
  `enable` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='附件图片表';

-- 正在导出表  scm_db.imgs 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `imgs` DISABLE KEYS */;
/*!40000 ALTER TABLE `imgs` ENABLE KEYS */;

-- 导出  表 scm_db.input_invoice 结构
CREATE TABLE IF NOT EXISTS `input_invoice` (
  `id` int NOT NULL,
  `purchase_order_id` int DEFAULT NULL COMMENT '采购订单id',
  `invoice_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发票附件上传',
  `payment_this_time` decimal(18,2) DEFAULT NULL COMMENT '本次付款金额(若小于订单金额则提交完毕之后与订单金额相减）',
  `invoice_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发票的类型(数据库字典）',
  `incoice_num` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发票号码',
  `incoice_time` datetime DEFAULT NULL COMMENT '收票时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='进项发票';

-- 正在导出表  scm_db.input_invoice 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `input_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `input_invoice` ENABLE KEYS */;

-- 导出  表 scm_db.inventory_counts 结构
CREATE TABLE IF NOT EXISTS `inventory_counts` (
  `id` int NOT NULL,
  `inventory_type` varchar(255) DEFAULT NULL COMMENT '盘点类型',
  `inventory_code` varchar(255) DEFAULT NULL COMMENT '盘点单编号',
  `inventory_date` datetime DEFAULT NULL COMMENT '盘点开始日期',
  `inventory_end_date` datetime DEFAULT NULL COMMENT '盘点结束日期',
  `inventory_person` varchar(255) DEFAULT NULL COMMENT '盘点员',
  `inventory_department` varchar(255) DEFAULT NULL COMMENT '盘点员归属部门',
  `inventory_warehouse_id` int DEFAULT NULL COMMENT '盘点仓库',
  `product_management_id` int DEFAULT NULL COMMENT '盘点产品明细',
  `inventory_loss` varchar(255) DEFAULT NULL COMMENT '盘亏总数',
  `inventory_win` varchar(255) DEFAULT NULL COMMENT '盘盈总数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='库存盘点';

-- 正在导出表  scm_db.inventory_counts 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `inventory_counts` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_counts` ENABLE KEYS */;

-- 导出  表 scm_db.login_log 结构
CREATE TABLE IF NOT EXISTS `login_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int DEFAULT NULL,
  `input_time` timestamp NULL DEFAULT (now()),
  `ip` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb3 COMMENT='管理员登录记录表';

-- 正在导出表  scm_db.login_log 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `login_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_log` ENABLE KEYS */;

-- 导出  表 scm_db.other_in_warehouse 结构
CREATE TABLE IF NOT EXISTS `other_in_warehouse` (
  `id` int NOT NULL,
  `other_in_warehouse` varchar(255) DEFAULT NULL COMMENT '入库类型',
  `warehouser_id` int DEFAULT NULL COMMENT '入库仓库id',
  `other_in_warehouse_code` varchar(255) DEFAULT NULL COMMENT '其他入库单编号（自动生成）',
  `product_management_id` int DEFAULT NULL COMMENT '入库产品明细',
  `other_in_warehouse_num` int DEFAULT NULL COMMENT '入库产品总数',
  `ohter_in_warehouse_money` decimal(10,2) DEFAULT NULL COMMENT '入库产品总额',
  `in_warehouse_confirm` bit(1) DEFAULT NULL COMMENT '入库确认',
  `other_warehouse_imgs_id` int DEFAULT NULL COMMENT '入库确认图片（附件）',
  `other_warehouse_date` datetime DEFAULT NULL COMMENT '入库时间',
  `in_warehouse_person` int DEFAULT NULL COMMENT '入库人',
  `person_department` int DEFAULT NULL COMMENT '归属部门',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='其他入库单';

-- 正在导出表  scm_db.other_in_warehouse 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `other_in_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `other_in_warehouse` ENABLE KEYS */;

-- 导出  表 scm_db.other_out_warehouse 结构
CREATE TABLE IF NOT EXISTS `other_out_warehouse` (
  `id` int NOT NULL,
  `other_out_warehouse` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '出库类型',
  `warehouser_id` int DEFAULT NULL COMMENT '出库仓库id',
  `other_out_warehouse_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '其他出库单编号（自动生成）',
  `product_management_id` int DEFAULT NULL COMMENT '出库产品明细',
  `other_out_warehouse_num` int DEFAULT NULL COMMENT '出库产品总数',
  `ohter_out_warehouse_money` decimal(10,2) DEFAULT NULL COMMENT '出库产品总额',
  `out_warehouse_confirm` bit(1) DEFAULT NULL COMMENT '出库确认',
  `other_warehouse_imgs_id` int DEFAULT NULL COMMENT '出库确认图片（附件）',
  `other_warehouse_date` datetime DEFAULT NULL COMMENT '出库时间',
  `out_warehouse_person` int DEFAULT NULL COMMENT '出库人',
  `person_department` int DEFAULT NULL COMMENT '归属部门',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='其他出库单';

-- 正在导出表  scm_db.other_out_warehouse 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `other_out_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `other_out_warehouse` ENABLE KEYS */;

-- 导出  表 scm_db.payment 结构
CREATE TABLE IF NOT EXISTS `payment` (
  `id` int NOT NULL,
  `purchase_order_id` int DEFAULT NULL COMMENT '采购订单的id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='采购订单的付款单';

-- 正在导出表  scm_db.payment 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;

-- 导出  表 scm_db.pay_plan 结构
CREATE TABLE IF NOT EXISTS `pay_plan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchase_order_pay` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '付款项（在数据字典）',
  `purchase_proprtion` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '付款比例',
  `purchase_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '付款方式（在数据字典）',
  `purchase_date` datetime DEFAULT NULL COMMENT '计划付款日期',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `purchase_order_id` int DEFAULT NULL COMMENT '采购订单id',
  PRIMARY KEY (`id` DESC) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='采购订单付款计划表';

-- 正在导出表  scm_db.pay_plan 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `pay_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay_plan` ENABLE KEYS */;

-- 导出  表 scm_db.product_category 结构
CREATE TABLE IF NOT EXISTS `product_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_type` int DEFAULT NULL COMMENT '产品类型名称',
  `enter_person` int DEFAULT NULL COMMENT '提交人',
  `enter_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `product_attribute` int DEFAULT NULL COMMENT '产品属性',
  `enable` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='产品分类';

-- 正在导出表  scm_db.product_category 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;

-- 导出  表 scm_db.product_order 结构
CREATE TABLE IF NOT EXISTS `product_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品编码（自动生成）',
  `product_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品名称',
  `product_brand` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品品牌',
  `product_attribute` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品属性',
  `product_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品类型',
  `product_models` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品规格型号',
  `priduct_unit` int DEFAULT NULL COMMENT '产品单位',
  `purchase_permissions` bit(1) DEFAULT NULL COMMENT '产品采购权限',
  `product_imgs_id` int DEFAULT NULL COMMENT '产品图片',
  `presented_permissions` bit(1) DEFAULT NULL COMMENT '产品赠送权限',
  `product_unit_price` decimal(50,0) DEFAULT NULL COMMENT '采购单价',
  `sale_permissions` bit(1) DEFAULT NULL COMMENT '产品销售权限',
  `sample_product_num` int DEFAULT NULL COMMENT '样品数量(添加样品)',
  `total_price` decimal(20,6) DEFAULT NULL COMMENT '产品总价',
  `sample_product_price` decimal(20,6) DEFAULT NULL COMMENT '样品单价(添加样品)',
  `historical_quotes` decimal(20,6) DEFAULT NULL COMMENT '历史报价',
  `purchase_num` int DEFAULT NULL COMMENT '采购数量需求(用于 采购申请)',
  `ifneed_quote` bit(1) DEFAULT NULL COMMENT '是否寻求报价（0不需要报价，1需要报价\r\n',
  `enable` bit(1) DEFAULT b'1' COMMENT '假删除',
  `enter_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '录入人',
  `enter_time` datetime DEFAULT NULL COMMENT '录入时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='产品在订单里面的展示';

-- 正在导出表  scm_db.product_order 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `product_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_order` ENABLE KEYS */;

-- 导出  表 scm_db.product_show 结构
CREATE TABLE IF NOT EXISTS `product_show` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品编码（自动生成）',
  `product_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品名称',
  `product_brand` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品品牌',
  `product_attribute` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品属性',
  `product_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品类型',
  `product_models` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '产品规格型号',
  `priduct_unit` int DEFAULT NULL COMMENT '产品单位',
  `purchase_permissions` bit(1) DEFAULT NULL COMMENT '产品采购权限',
  `product_imgs_id` int DEFAULT NULL COMMENT '产品图片id',
  `presented_permissions` bit(1) DEFAULT NULL COMMENT '产品赠送权限',
  `product_unit_price` decimal(50,0) DEFAULT NULL COMMENT '标准采购单价',
  `sale_permissions` bit(1) DEFAULT NULL COMMENT '产品销售权限',
  `enable` bit(1) DEFAULT b'1' COMMENT '假删除',
  `enter_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '录入人',
  `enter_time` datetime DEFAULT NULL COMMENT '录入时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='产品展示';

-- 正在导出表  scm_db.product_show 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `product_show` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_show` ENABLE KEYS */;

-- 导出  表 scm_db.product_supplier 结构
CREATE TABLE IF NOT EXISTS `product_supplier` (
  `id` int NOT NULL,
  `product_show_id` int DEFAULT NULL COMMENT '产品展示id',
  `supplier_id` int DEFAULT NULL COMMENT '供应商id',
  `product_unit_price` decimal(10,2) DEFAULT NULL COMMENT '标准采购单价（含税）',
  `product_price` decimal(10,2) DEFAULT NULL COMMENT '采购单价（含税）',
  `discount_rate` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '折扣率',
  `tax` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '增值税率',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='产品-----供应商关系表';

-- 正在导出表  scm_db.product_supplier 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `product_supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_supplier` ENABLE KEYS */;

-- 导出  表 scm_db.product_warehouse 结构
CREATE TABLE IF NOT EXISTS `product_warehouse` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_show` int DEFAULT NULL COMMENT '产品展示id',
  `enable` bit(1) DEFAULT b'1' COMMENT '假删除',
  `enter_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '录入人',
  `enter_time` datetime DEFAULT NULL COMMENT '录入时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `update_person` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '更新人',
  `product_num` int DEFAULT NULL COMMENT '库存数量',
  `warehouse_id` int DEFAULT NULL COMMENT '仓库id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='产品在库存';

-- 正在导出表  scm_db.product_warehouse 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `product_warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_warehouse` ENABLE KEYS */;

-- 导出  表 scm_db.purchase_apply 结构
CREATE TABLE IF NOT EXISTS `purchase_apply` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '采购申请编号',
  `employee_id` int DEFAULT NULL COMMENT '申请人id',
  `enter_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '申请时间',
  `delivery_demand_time` datetime DEFAULT NULL COMMENT '到货需求日期',
  `warehouse_id` int DEFAULT NULL COMMENT '入库仓库',
  `source` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '需求来源',
  `remark` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `all_price` decimal(10,2) DEFAULT NULL COMMENT '采购价格总额',
  `approval_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批结果（默认前台不显示，审批时候显示默认为0,1为同意',
  `approval_time` datetime DEFAULT NULL COMMENT '审批时间',
  `approval_person_id` int DEFAULT NULL COMMENT '审批人id',
  `rfq_quote` int DEFAULT NULL COMMENT '是否需要询价（1需要，0不需要）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='采购申请（还未购买）';

-- 正在导出表  scm_db.purchase_apply 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `purchase_apply` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_apply` ENABLE KEYS */;

-- 导出  表 scm_db.purchase_need_pool 结构
CREATE TABLE IF NOT EXISTS `purchase_need_pool` (
  `id` int NOT NULL,
  `purchase_product_details_id` int DEFAULT NULL COMMENT '采购状态id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='采购需求池展示（采购状态，付款状态，入库状态）';

-- 正在导出表  scm_db.purchase_need_pool 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `purchase_need_pool` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_need_pool` ENABLE KEYS */;

-- 导出  表 scm_db.purchase_order 结构
CREATE TABLE IF NOT EXISTS `purchase_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` int DEFAULT NULL COMMENT '供应商id',
  `purchase_order_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '采购订单名称',
  `purchase_sign_date` datetime DEFAULT NULL COMMENT '订单签订日期',
  `purchase_delivery_date` datetime DEFAULT NULL COMMENT '订单交付日期',
  `purchase_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '采购订单编号（自动生成）',
  `department_id` int DEFAULT NULL COMMENT '部门的id',
  `employee_id` int DEFAULT NULL COMMENT '员工的id',
  `warehouse_id` int DEFAULT NULL COMMENT '入库的仓库id',
  `purchase_order_img_id` int DEFAULT NULL COMMENT '合同附件id',
  `discount_amount` decimal(18,2) DEFAULT NULL COMMENT '优惠金额',
  `purchase_apply_id` int DEFAULT NULL COMMENT '订单申请表',
  `approval_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批结果（默认前台不显示，审批时候显示默认为0,1为同意',
  `approval_time` datetime DEFAULT NULL COMMENT '审批时间',
  `approval_person_id` int DEFAULT NULL COMMENT '审批人id',
  `total_price` decimal(18,2) DEFAULT NULL COMMENT '订单总金额',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='采购订单';

-- 正在导出表  scm_db.purchase_order 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;

-- 导出  表 scm_db.purchase_product_details 结构
CREATE TABLE IF NOT EXISTS `purchase_product_details` (
  `id` int NOT NULL,
  `product_supplier_id` int DEFAULT NULL COMMENT '供应商产品信息表id',
  `purchase_num` int DEFAULT NULL COMMENT '采购需求数量',
  `quote` bit(1) DEFAULT NULL COMMENT '是否寻求报价（0是寻求报价，1不寻求报价）',
  `product_warehouse_id` int DEFAULT NULL COMMENT '产品所在库存id',
  `purchase_apply_id` int DEFAULT NULL COMMENT '采购申请表的id',
  `total_price` decimal(10,2) DEFAULT NULL COMMENT '总价格（单价*数量）',
  `purchase_num_real` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '实际采购数量',
  `approval` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '审批是否通过根据申请表的审批来判断',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='采购明细表----申请（还未购买）';

-- 正在导出表  scm_db.purchase_product_details 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `purchase_product_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_product_details` ENABLE KEYS */;

-- 导出  表 scm_db.qualificationinfo 结构
CREATE TABLE IF NOT EXISTS `qualificationinfo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL DEFAULT '0' COMMENT '证书名称',
  `type` varchar(20) NOT NULL DEFAULT '0' COMMENT '证书类别',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商id',
  `attachment_id` int NOT NULL DEFAULT '0' COMMENT '附件id',
  `enable` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='资质信息表';

-- 正在导出表  scm_db.qualificationinfo 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `qualificationinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `qualificationinfo` ENABLE KEYS */;

-- 导出  表 scm_db.scm_dict_data 结构
CREATE TABLE IF NOT EXISTS `scm_dict_data` (
  `dict_code` bigint NOT NULL AUTO_INCREMENT COMMENT '字典编码',
  `dict_sort` int DEFAULT '0' COMMENT '字典排序',
  `dict_label` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '字典标签',
  `dict_value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '字典键值',
  `dict_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '字典类型',
  `css_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '样式属性（其他样式扩展）',
  `list_class` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '表格回显样式',
  `is_default` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'N' COMMENT '是否默认（Y是 N否）',
  `status` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_code`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='字典数据表';

-- 正在导出表  scm_db.scm_dict_data 的数据：~52 rows (大约)
/*!40000 ALTER TABLE `scm_dict_data` DISABLE KEYS */;
INSERT INTO `scm_dict_data` (`dict_code`, `dict_sort`, `dict_label`, `dict_value`, `dict_type`, `css_class`, `list_class`, `is_default`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES
	(1, 0, '成品供应商', '0', 'supplier_type', NULL, NULL, 'Y', '0', 'admin', '2024-11-21 09:24:26', '', NULL, '供应商分类'),
	(2, 0, '零件供应商', '1', 'supplier_type', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:24:27', '', NULL, '供应商分类'),
	(3, 0, '集合供应商', '2', 'supplier_type', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:24:28', '', NULL, '供应商分类'),
	(4, 0, '潜在供应商', '0', 'supplier_state', NULL, NULL, 'Y', '0', 'admin', '2024-11-21 09:25:57', '', NULL, '供应商状态'),
	(5, 0, '合格供应商', '1', 'supplier_state', NULL, NULL, 'N', '0', 'admin', '2024-11-21 10:22:43', '', NULL, '供应商状态'),
	(6, 0, '一级供应商', '', 'supplier_level', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:25:57', '', NULL, '供应商评级（大于等于85%）'),
	(7, 0, '二级供应商', '', 'supplier_level', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:25:57', '', NULL, '供应商评级（大于等于75%）'),
	(8, 0, '三级供应商', '', 'supplier_level', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:25:58', '', NULL, '供应商评级（大于等于60%）'),
	(9, 0, '不合格', '', 'supplier_level', NULL, NULL, 'N', '0', 'admin', '2024-11-21 10:17:23', '', NULL, '供应商评级'),
	(10, 0, '增值税专用发票', '', 'tax_type', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:30:23', '', NULL, '税种'),
	(11, 0, '普通发票', '', 'tax_type', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:30:26', '', NULL, '税种'),
	(12, 0, '监理资质证书', '', 'certificate_type', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:40:49', '', NULL, '证书类型'),
	(13, 0, '企业经营执照', '', 'certificate_type', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:40:49', '', NULL, '证书类型'),
	(14, 0, '实用新型专利', '', 'certificate_type', NULL, NULL, 'N', '0', 'admin', '2024-11-21 09:40:50', '', NULL, '证书类型'),
	(15, 0, '月结', '', 'supplier_sign_deadline', NULL, NULL, 'N', '0', 'admin', '2024-11-21 10:28:35', '', NULL, '结算期限'),
	(16, 0, '季结', '', 'supplier_sign_deadline', NULL, NULL, 'N', '0', 'admin', '2024-11-21 10:28:36', '', NULL, '结算期限'),
	(17, 0, '现结', '', 'supplier_sign_deadline', NULL, NULL, 'N', '0', 'admin', '2024-11-21 10:28:36', '', NULL, '结算期限'),
	(20, 0, '产品属性-成品', '', 'product_attribute', NULL, NULL, 'N', '0', '', '2024-11-21 11:50:36', '', NULL, '产品类型名'),
	(21, 0, '产品属性-零件', '', 'product_attribute', NULL, NULL, 'N', '0', '', '2024-11-21 11:50:37', '', NULL, '产品类型名'),
	(22, 0, '台', '', 'product_unit', NULL, NULL, 'N', '0', '', NULL, '', NULL, '产品单位'),
	(23, 0, '套', '', 'product_unit', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
	(24, 0, '件', '', 'product_unit', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
	(25, 0, '个', '', 'product_unit', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
	(26, 0, '盒', '', 'product_unit', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
	(27, 0, '箱', '', 'product_unit', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
	(28, 0, '片', '', 'product_unit', NULL, NULL, 'N', '0', '', NULL, '', NULL, NULL),
	(30, 0, '废品', '', 'warehouse_nature', NULL, NULL, 'N', '0', '', NULL, '', NULL, '仓库性质'),
	(31, 0, '存货', '', 'warehouse_nature', NULL, NULL, 'N', '0', '', NULL, '', NULL, '仓库性质'),
	(32, 0, '现场', '', 'warehouse_nature', NULL, NULL, 'N', '0', '', NULL, '', NULL, '仓库性质'),
	(33, 0, '补货', '', 'require_source', NULL, NULL, 'N', '0', '', NULL, '', NULL, '需求来源'),
	(34, 0, '库存预警', '', 'require_source', NULL, NULL, 'N', '0', '', NULL, '', NULL, '需求来源'),
	(35, 0, '工单需求', '', 'require_source', NULL, NULL, 'N', '0', '', NULL, '', NULL, '需求来源'),
	(36, 0, '整批', '', 'purchase_order_arrival', NULL, NULL, 'N', '0', '', NULL, '', NULL, '到货批次'),
	(37, 0, '第一批', '', 'purchase_order_arrival', NULL, NULL, 'N', '0', '', NULL, '', NULL, '到货批次'),
	(38, 0, '第二批', '', 'purchase_order_arrival', NULL, NULL, 'N', '0', '', NULL, '', NULL, '到货批次'),
	(39, 0, '第三批', '', 'purchase_order_arrival', NULL, NULL, 'N', '0', '', NULL, '', NULL, '到货批次'),
	(40, 0, '整批货款', '', 'purchase_order_pay', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款项'),
	(41, 0, '定金', '', 'purchase_order_pay', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款项'),
	(42, 0, '第一批货款', '', 'purchase_order_pay', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款项'),
	(43, 0, '第二批货款', '', 'purchase_order_pay', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款项'),
	(44, 0, '第三批货款', '', 'purchase_order_pay', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款项'),
	(45, 0, '银行转账', '', 'purchase_method', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款方式'),
	(46, 0, '微信支付', '', 'purchase_method', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款方式'),
	(47, 0, '现金支付', '', 'purchase_method', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款方式'),
	(48, 0, '支付宝支付', '', 'purchase_method', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款方式'),
	(49, 0, '银行支票', '', 'purchase_method', NULL, NULL, 'N', '0', '', NULL, '', NULL, '付款方式'),
	(50, 0, '库存预警', '', 'allocate_type', NULL, NULL, 'N', '0', '', NULL, '', NULL, '调拨类型'),
	(51, 0, '满仓调离', '', 'allocate_type', NULL, NULL, 'N', '0', '', NULL, '', NULL, '调拨类型'),
	(52, 0, '期初盘点', '', 'inventory_type', NULL, NULL, 'N', '0', '', NULL, '', NULL, '盘点类型'),
	(53, 0, '存货盘点', '', 'inventory_type', NULL, NULL, 'N', '0', '', NULL, '', NULL, '盘点类型'),
	(54, 0, '期末盘点', '', 'inventory_type', NULL, NULL, 'N', '0', '', NULL, '', NULL, '盘点类型'),
	(55, 0, '销售入库类型', '', 'other_out_warehouse', NULL, NULL, 'N', '0', '', NULL, '', NULL, '出库类型');
/*!40000 ALTER TABLE `scm_dict_data` ENABLE KEYS */;

-- 导出  表 scm_db.scm_dict_type 结构
CREATE TABLE IF NOT EXISTS `scm_dict_type` (
  `dict_id` bigint NOT NULL AUTO_INCREMENT COMMENT '字典主键',
  `dict_name` varchar(100) DEFAULT '' COMMENT '字典名称',
  `dict_type` varchar(100) DEFAULT '' COMMENT '字典类型',
  `status` char(1) DEFAULT '0' COMMENT '状态（0正常 1停用）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`dict_id`),
  UNIQUE KEY `dict_type` (`dict_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='字典类型表';

-- 正在导出表  scm_db.scm_dict_type 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `scm_dict_type` DISABLE KEYS */;
INSERT INTO `scm_dict_type` (`dict_id`, `dict_name`, `dict_type`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES
	(1, '供应商类型', 'supplier_type', '0', '', '2024-11-21 13:14:41', '', '2024-11-21 13:14:43', '供应商类型列表');
/*!40000 ALTER TABLE `scm_dict_type` ENABLE KEYS */;

-- 导出  表 scm_db.supplier 结构
CREATE TABLE IF NOT EXISTS `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '供应商编码 自动生成',
  `supplier_num` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '供应商准入编号',
  `supplier_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '供应商名称',
  `supplier_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '供应商分类（数据库字典）',
  `supplier_state` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '供应商状态(注册时)/评级(主管评分后)',
  `supplier_address` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '供应商地址（三级联动+详细地址）',
  `invoice_header` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发票抬头',
  `tax_num` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '发票税号',
  `tax_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '税种',
  `tax_rate` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '税率（13% 9%）',
  `bank` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '开户银行（四大行）',
  `bank_num` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '银行账号',
  `contactinfo_id` int DEFAULT NULL COMMENT '联系人_id',
  `attachment_id` int DEFAULT NULL COMMENT '附件_id',
  `enter_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '录入时间',
  `enter_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '录入人',
  `update_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `update_person` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '修改人',
  `remark` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `stop` bit(1) DEFAULT b'1' COMMENT '禁用：1 可用',
  `enable` bit(1) DEFAULT b'1' COMMENT '删除：1可用',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='供应商信息表';

-- 正在导出表  scm_db.supplier 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;

-- 导出  表 scm_db.supplier_deliver_goods 结构
CREATE TABLE IF NOT EXISTS `supplier_deliver_goods` (
  `id` int NOT NULL,
  `purchase_order_id` int DEFAULT NULL COMMENT '采购订单id',
  `deliver_person_id` int DEFAULT NULL COMMENT '送货联系人id',
  `deliver_code` varchar(255) DEFAULT NULL COMMENT '送货单编号',
  `deliver_date` datetime DEFAULT NULL COMMENT '供应商送货时间',
  `plan_arrival_date` datetime DEFAULT NULL COMMENT '预计到货时间',
  `arrival_date` datetime DEFAULT NULL COMMENT '实际送达时间',
  `arrival_imgs_id` int DEFAULT NULL COMMENT '图片',
  `sure` bit(1) DEFAULT NULL COMMENT '送货确认',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商送货表';

-- 正在导出表  scm_db.supplier_deliver_goods 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `supplier_deliver_goods` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_deliver_goods` ENABLE KEYS */;

-- 导出  表 scm_db.supplier_enter_rule 结构
CREATE TABLE IF NOT EXISTS `supplier_enter_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0' COMMENT '条例名称',
  `create_person` varchar(50) NOT NULL DEFAULT '0' COMMENT '创建人',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `enable` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商准入条例';

-- 正在导出表  scm_db.supplier_enter_rule 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `supplier_enter_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_enter_rule` ENABLE KEYS */;

-- 导出  表 scm_db.supplier_enter_rule_data 结构
CREATE TABLE IF NOT EXISTS `supplier_enter_rule_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `enter_rule_id` int DEFAULT NULL,
  `rules` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '多个评估项',
  `max_score` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '最高分（自己写的）',
  `total_score` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '总分（根据每一项得分算出来）',
  `score` varchar(50) DEFAULT NULL COMMENT '咱们给打分（评分）',
  `remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '备注',
  `enable` bit(1) DEFAULT b'1' COMMENT '1 可用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='准则条例中的>>>多个评估项';

-- 正在导出表  scm_db.supplier_enter_rule_data 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `supplier_enter_rule_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_enter_rule_data` ENABLE KEYS */;

-- 导出  表 scm_db.supplier_sample_management 结构
CREATE TABLE IF NOT EXISTS `supplier_sample_management` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` int DEFAULT NULL COMMENT '供应商信息',
  `isnew` bit(1) DEFAULT NULL COMMENT '是否是新品0非新品',
  `mailing_time` datetime DEFAULT NULL COMMENT '邮寄时间',
  `mailing_code` varchar(50) DEFAULT NULL COMMENT '邮寄单号',
  `enter_person` varchar(50) DEFAULT NULL COMMENT '录入人',
  `enter_time` datetime DEFAULT NULL COMMENT '录入时间',
  `enable` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商提交的的样品管理';

-- 正在导出表  scm_db.supplier_sample_management 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `supplier_sample_management` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_sample_management` ENABLE KEYS */;

-- 导出  表 scm_db.supplier_sign 结构
CREATE TABLE IF NOT EXISTS `supplier_sign` (
  `id` int NOT NULL AUTO_INCREMENT,
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商_id',
  `start_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '签约开始日期',
  `end_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '签约结束日期',
  `supplier_sign_deadline` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '结算期限',
  `credit_limit` varchar(50) DEFAULT NULL COMMENT '信用额度',
  `purchase_person` int DEFAULT NULL COMMENT '采购负责人(根据部门选择)',
  `purchase_department` varchar(50) DEFAULT NULL COMMENT '采购部门',
  `imgs_id` int DEFAULT NULL COMMENT '******************未定/可能用不到',
  `enable` bigint DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='供应商签约';

-- 正在导出表  scm_db.supplier_sign 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `supplier_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `supplier_sign` ENABLE KEYS */;

-- 导出  表 scm_db.sys_notice 结构
CREATE TABLE IF NOT EXISTS `sys_notice` (
  `notice_id` int NOT NULL AUTO_INCREMENT COMMENT '公告ID',
  `notice_title` varchar(50) NOT NULL COMMENT '公告标题',
  `notice_type` char(1) NOT NULL COMMENT '公告类型（1通知 2公告）',
  `notice_content` longblob COMMENT '公告内容',
  `status` char(1) DEFAULT '0' COMMENT '公告状态（0正常 1关闭）',
  `create_by` varchar(64) DEFAULT '' COMMENT '创建者',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_by` varchar(64) DEFAULT '' COMMENT '更新者',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通知公告表';

-- 正在导出表  scm_db.sys_notice 的数据：~2 rows (大约)
/*!40000 ALTER TABLE `sys_notice` DISABLE KEYS */;
INSERT INTO `sys_notice` (`notice_id`, `notice_title`, `notice_type`, `notice_content`, `status`, `create_by`, `create_time`, `update_by`, `update_time`, `remark`) VALUES
	(1, '温馨提醒：2018-07-01 若依新版本发布啦', '2', _binary 0xe696b0e78988e69cace58685e5aeb9, '0', 'admin', '2024-02-29 09:41:22', '', NULL, '管理员'),
	(2, '维护通知：2018-07-01 若依系统凌晨维护', '1', _binary 0xe7bbb4e68aa4e58685e5aeb9, '0', 'admin', '2024-02-29 09:41:22', '', NULL, '管理员');
/*!40000 ALTER TABLE `sys_notice` ENABLE KEYS */;

-- 导出  表 scm_db.warehouse 结构
CREATE TABLE IF NOT EXISTS `warehouse` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '仓库名称',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '仓库编码(自动生成)',
  `address` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '仓库地址（三级联动+详细地址）',
  `capacity` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '仓库容量',
  `nature` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'b''1''' COMMENT '仓库性质（数据字典）',
  `company_department_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'b''1''' COMMENT '公司部门id',
  `warehouse_leader` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库负责人',
  `phone` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '仓库负责人电话',
  `min_count` int DEFAULT NULL COMMENT '最低库存预警',
  `max_count` int DEFAULT NULL COMMENT '最高库存预警',
  `product_management_id` int DEFAULT NULL COMMENT '入库产品信息id',
  `instore_num` int DEFAULT NULL COMMENT '入库数量',
  `now_count` int DEFAULT NULL COMMENT '当前库存数量',
  `rent` decimal(20,6) DEFAULT NULL COMMENT '租金',
  `end_time` datetime DEFAULT NULL COMMENT '到期时间',
  `stop` bit(1) NOT NULL DEFAULT b'1' COMMENT '仓库状态：是否可用    1可用',
  `enable` bit(1) DEFAULT b'1',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='仓库';

-- 正在导出表  scm_db.warehouse 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `warehouse` DISABLE KEYS */;
/*!40000 ALTER TABLE `warehouse` ENABLE KEYS */;

-- 导出  表 scm_db.warehouse_allocate 结构
CREATE TABLE IF NOT EXISTS `warehouse_allocate` (
  `id` int NOT NULL,
  `allocate_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '调拨类型(数据库字典）',
  `allocate_date` datetime DEFAULT NULL COMMENT '调拨申请日期',
  `allocate_expectation` datetime DEFAULT NULL COMMENT '期望到货日期',
  `apply_person_id` int DEFAULT NULL COMMENT '申请人',
  `apply_department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '申请部门',
  `allocate_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '调拨单编号(自动生成）',
  `out_warehouse` int DEFAULT NULL COMMENT '调出仓库id',
  `in_warehouse` int DEFAULT NULL COMMENT '调入仓库id',
  `allocate_product_money` decimal(10,2) DEFAULT NULL COMMENT '调拨产品总额',
  `allocate_product_num` int DEFAULT NULL COMMENT '调拨产品总数',
  `product_management_id` int DEFAULT NULL COMMENT '调拨产品明细id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='库存调拨表';

-- 正在导出表  scm_db.warehouse_allocate 的数据：~0 rows (大约)
/*!40000 ALTER TABLE `warehouse_allocate` DISABLE KEYS */;
/*!40000 ALTER TABLE `warehouse_allocate` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
